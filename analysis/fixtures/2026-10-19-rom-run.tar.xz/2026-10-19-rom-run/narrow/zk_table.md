| Application | Parameters | Extraction | ZK, Q = 1 | ZK, Q = 2^64 | ZK after the last request | Everlasting WI | Completeness |
|---|---|---:|---:|---:|---:|---:|---:|
| RSA-2048 | ROM | 101.9 | 235.9 | 129.0 | 116.3 | 115.3 | 235.9 |
| ECDSA mDL | ROM | 101.3 | 234.7 | 129.0 | 116.6 | 115.6 | 234.7 |
| SHA-256 | ROM | 105.3 | 245.6 | 129.0 | 117.4 | 116.4 | 245.6 |
| ML-DSA-44 | ROM | 101.4 | 234.6 | 129.0 | 116.5 | 115.5 | 234.6 |
| ML-DSA mDL | ROM | 99.7 | 233.9 | 129.0 | 115.1 | 114.1 | 233.9 |
